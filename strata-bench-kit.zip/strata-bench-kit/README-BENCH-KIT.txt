Strata PR #3607 (Windows SYCL) — BENCH キット
=============================================

これは何？
  本家 Strata 純正の BENCH.bat（コミュニティベンチ）を、セットアップ無しの
  exe 単体パッケージ（0.1.60.1-windows-x86_64-sycl）で動かすためのキットです。
  実行するとサーバを自動で起動して固定のテスト一式を流し、共有用のレポートが
  bench\results\<日付>-community-<GPU>-<モデル>\ に
  README.md（docs/COMMUNITY_BENCHMARKS.md 形式）＋ results.json で出来ます。
  イシューに貼るのはこのフォルダごとが正解です（個人情報は自動で伏せられます）。

中身
  RUN-BENCH.bat           … かんたん起動（★基本はこれを使う）
  BENCH.bat               … 純正バッチ（無改造）
  .venv\Scripts\          … Python 3.12.10 同梱ランタイム＋依存一式
                            （BENCH.bat が要求する場所に配置済み）
  tools\ serve\ strata_control\ strata_cli\ … repo の必要部分（純正・無改造）
  strata-iq3_s-sycl.json  … SYCL 用の実行設定（RUN-BENCH が自動生成する）

手順（かんたん）
  1. RUN-BENCH.bat をダブルクリック。
  2. GGUF（パック）のフォルダを聞かれるので入力（ドラッグ＆ドロップ可）。
     → .gguf が番号一覧で出るので --native（通常1）／--ple-gguf（通常2）を選ぶ
       （Enter 連打で既定値）。MTP フォルダは任意（無ければ Enter）。
     → strata.exe はキットの隣や中から自動で探す。見つからない時だけ
       パッケージフォルダを聞かれる。
  3. 設定（strata-iq3_s-sycl.json）が自動生成され、確認後に BENCH.bat が走る。
     サーバ起動（モデル読み込みに数分）→ テスト約3〜10分 → 結果表示。
     ポート 8080 を使うので、他で使っていないこと（XeStrata の 8095 とは別）。

手編集する場合
  strata-iq3_s-sycl.json の EDIT-ME のパス（exe／--pack／--native／--ple-gguf／
  tokenizer の5か所）を実物に書き換えて、BENCH.bat をダブルクリック。
  tokenizer は vocab.json が入っているフォルダを指定する。
  MTP を使う場合は args の "--serve" の直前に "--mtp", "MTPのフォルダ" を足す。

詰まったら
  - サーバが起動しない： このフォルダの strata-iq3_s-sycl.log と、
    BENCH の画面に出るエンジンログ抜粋を Muse に渡す。
  - REFUSED（experts are neither in VRAM nor mirrored）が出る：
    設定の env の STRATA_MIRROR_MIB を上げるか、--max-context を下げる。
  - 初回は SYCL カーネルの JIT コンパイルで読み込みが長い（正常）。
    環境変数（SYCL_CACHE_PERSISTENT=0 等）は設定ファイルの env に入れてあるので
    手動設定は不要。
  ※ VPS 側で「サーバ起動 → tokenizer を探しに行く」ところまでと、
     RUN-BENCH の設定自動生成は検証済み。実モデルでの完走はメイン PC での
     初回実行が初検証になる。
