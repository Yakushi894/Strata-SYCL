// tools/vision/own/cpu_tier.h - what a kernel tier of the CPU tower sees: the kernel table type, the tier getters, and the few out-of-line helpers the tiers call.
//
// The tier files cpu_kernels_avx2.cpp and cpu_kernels_avx512.cpp are compiled with wider instruction-set flags than the rest of the program.  An inline function
// with external linkage (a C++ standard-library template, an inline helper of another header) compiled there can be the copy the linker keeps for the WHOLE
// program, and then a CPU without that instruction set dies in code that has nothing to do with the tier.  So those files, and cpu_kernels_impl.h, include only
// this header (plain C headers) and <immintrin.h>, keep everything of their own in an anonymous namespace (internal linkage), and call library code only through
// the out-of-line functions declared here, which are compiled at the baseline (cpu_ops.cpp).
#pragma once

#include <stddef.h>
#include <stdint.h>

namespace strata_vit {

struct CpuOps {
    const char* name;
    int MR, NR;        // the register tile of the product: MR rows of A against NR columns of B

    // Packs the weight rows n0 .. n0 + nvalid (nvalid <= NR; the rest of the NR columns are zero) of W[N][K] (row-major, row stride ldw elements), columns
    // k0 .. k0 + kc, into dst[kc][NR] float32.  kind: 0 float32, 1 BF16, 2 F16 (W points at elements of that type).
    void (*pack_w)(const void* W, int kind, size_t ldw, int n0, int nvalid, int k0, int kc, float* dst);

    // n contiguous 16-bit weights (kind 1 BF16, 2 F16) to float32 (bit exact).  The tower keeps its matrices as 16-bit panels [tile][K][NR] made once at load,
    // and a product task converts the panel it needs into a float buffer: no transposition in the hot path.
    void (*conv)(const void* src, int kind, size_t n, float* dst);

    // C[M][N] = init-mode + A[M][K] * B[K][N]; A rows lda apart, B rows ldb apart (B must be readable up to the next multiple of NR columns), C rows ldc apart.
    // init 0: C = bias (or zero) + A*B; 1: C += A*B; 2: C = C + bias + A*B.  bias: N floats or null.
    void (*gemm)(const float* A, size_t lda, int M, const float* B, size_t ldb, int K, int N, float* C, size_t ldc, int init, const float* bias);

    // x = gelu_tanh(x) on rows x n of a matrix with row stride ldx
    void (*gelu)(float* x, size_t ldx, int rows, int n);
    // y = LayerNorm(x) * w + b for one row of D
    void (*layernorm)(const float* x, float* y, int D, const float* w, const float* b, float eps);
    // x[i] += y[i], i < n
    void (*add)(float* x, const float* y, size_t n);
    // p[i] rounded to the 16-bit type and back (kind 1 BF16, 2 F16; round to nearest even): STRATA_VIT_REF_ROUND, the inputs of the products as ggml's CPU path hands them
    void (*round16)(float* p, size_t n, int kind);
    // One key tile of the online softmax for qrows query rows: S[qrows][nkeys] (row stride lds, already scaled) becomes P = exp(S - m_new) in place, the running
    // max m[r] and sum l[r] are updated and the context rows O[r][0..hd) (row stride ldo) are rescaled by exp(m_old - m_new) (O's P*V is added afterwards).
    void (*softmax_update)(float* S, size_t lds, int qrows, int nkeys, float* m, float* l, float* O, size_t ldo, int hd);
    // The two loops of the tower whose floating-point result depends on the compiler's multiply-add contraction, so they are compiled with each tier's flags
    // (vit_cpu.cpp itself is compiled for the baseline CPU, RESULTS-OWN-3V.md PART H): the rotary of one token row (q at row[0 .. heads*hd), k at
    // row[kstride ..); pair j of a head turns by (c1, s1)[j] for j < hd/4, else by (c2, s2)[j - hd/4]), and the position table's bilinear add of one row.
    void (*rope_row)(float* row, size_t kstride, int heads, int hd, const float* c1, const float* s1, const float* c2, const float* s2);
    void (*pos_add)(float* xr, const float* a, const float* b, const float* c, const float* d, float dx, float dy, int D);
};

const CpuOps& cpu_ops_scalar();
const CpuOps& cpu_ops_sse41();     // x86-64 only (both return the scalar table elsewhere): the tiers for CPUs without AVX2, multiply then add (no FMA)
const CpuOps& cpu_ops_avx();
const CpuOps& cpu_ops_avx2();      // defined only on x86-64 (cpu_ops_avx2 returns the scalar table elsewhere)
const CpuOps& cpu_ops_avx512();
const CpuOps& cpu_ops_neon();      // AArch64 only (cpu_ops_neon returns the scalar table elsewhere)

// expf of the C library, out of line and compiled at the baseline (cpu_ops.cpp): the scalar tails of the tiers' softmax
float cpu_tier_expf(float x);

// false when STRATA_VIT_CPU_TAIL1=0 (a diagnostic): the raw-vector tiers then take a last column tile of one vector or less through the two-vector product as
// before; out of line, compiled at the baseline (cpu_ops.cpp), read once
bool cpu_tier_one_vector_tail();

}  // namespace strata_vit
